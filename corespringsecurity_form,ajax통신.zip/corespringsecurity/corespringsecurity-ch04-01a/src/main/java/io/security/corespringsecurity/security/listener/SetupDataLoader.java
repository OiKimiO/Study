package io.security.corespringsecurity.security.listener;

import org.springframework.stereotype.Component;

@Component
public class SetupDataLoader {

}
