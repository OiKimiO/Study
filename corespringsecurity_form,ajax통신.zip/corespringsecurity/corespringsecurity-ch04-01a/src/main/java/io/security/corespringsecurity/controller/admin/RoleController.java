package io.security.corespringsecurity.controller.admin;

public class RoleController {

}
