package io.security.corespringsecurity.domain;

import javax.persistence.*;

import lombok.Data;

@Entity
@Data
public class Account {
	
	@Id
	@GeneratedValue
	private Long Id;
	private String username;
	private String password;
	private String email;
	private String age;
	private String role;
}
