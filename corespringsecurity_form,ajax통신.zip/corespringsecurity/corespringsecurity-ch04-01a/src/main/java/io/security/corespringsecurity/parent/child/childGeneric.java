package io.security.corespringsecurity.parent.child;

public class childGeneric {

}
