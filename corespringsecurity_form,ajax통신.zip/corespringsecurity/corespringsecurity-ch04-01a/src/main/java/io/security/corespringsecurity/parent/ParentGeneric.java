package io.security.corespringsecurity.parent;

public class ParentGeneric {

}
