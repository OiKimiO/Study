package io.security.corespringsecurity.repository;

public interface ResourceRepository {

}
